import { Component, OnInit } from '@angular/core';
import { Tweet } from '../tweet';
import { TweetService } from '../tweet.service';
import {NavigationEnd, Router} from '@angular/router'

@Component({
  selector: 'app-add-tweet',
  templateUrl: './add-tweet.component.html',
  styleUrls: ['./add-tweet.component.css']
})
export class AddTweetComponent implements OnInit {

    tweet: Tweet = new Tweet();
  constructor(private tweetService : TweetService, private router: Router) { }

  ngOnInit(): void {
    
  }

  onSubmit(){
    this.Savetweet();
    console.log(this.tweet);
  }

  Savetweet(){
    let loginId: string = localStorage.getItem('User');
    this.tweet.userLoginId= loginId
    this.tweetService.createTweet(this.tweet).subscribe(data => {
      console.log("called it" +data);
      this.goToTweets();
    },
    error => console.log(error));
    }

    goToTweets(){
      this.router.navigate(['/allTweets']);
    }


}
