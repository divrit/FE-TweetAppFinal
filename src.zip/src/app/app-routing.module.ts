import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddTweetComponent } from './add-tweet/add-tweet.component';
import { AuthGuard } from './auth.guard';
import { CreateUserComponent } from './create-user/create-user.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { MyTweetsComponent } from './my-tweets/my-tweets.component';
import { PostReplyComponent } from './post-reply/post-reply.component';
import { ReplyComponent } from './reply/reply.component';
import { TweetComponent } from './tweet/tweet.component';
import { UpdateTweetComponent } from './update-tweet/update-tweet.component';


const routes: Routes = [
  { path: '', component: HomeComponent , pathMatch:'full'},
  {path: "allTweets", component : TweetComponent, canActivate: [AuthGuard]},
  {path: "Add-Tweet", component : AddTweetComponent},
  {path: "Create-User", component : CreateUserComponent},
  {path: "my-tweets", component :MyTweetsComponent},
  {path: "update-tweet/:tweetID", component: UpdateTweetComponent },
  {path: "app-reply/:tweetID", component: ReplyComponent },
  {path: "app-post-reply/:TweetID", component: PostReplyComponent },
  {path: "login", component: LoginComponent},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
