import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from "@angular/common/http";
import { Injectable } from "@angular/core";

import { Observable } from "rxjs";
import { LoginService } from "./login.service";


@Injectable()
export class AuthInterceptor implements HttpInterceptor{


    constructor( private service: LoginService){}
    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        // throw new Error("Method not implemented.");
        let newReq=req;
        let Token= this.service.getToken();
    
        console.log("from interceptor     "+Token)

        if(Token!=null){
            console.log("iam in if")
           newReq= newReq.clone({setHeaders:{Authorization:`Bearer ${Token}`}})
          
        }

        return next.handle(newReq)

    }

}