import { Component, OnInit } from '@angular/core';
import { error } from 'selenium-webdriver';
import { User } from '../user';
import { UserService } from '../user.service';

@Component({
  selector: 'app-create-user',
  templateUrl: './create-user.component.html',
  styleUrls: ['./create-user.component.css']
})
export class CreateUserComponent implements OnInit {


    user : User =new User();
  constructor(private userService: UserService) { }

  ngOnInit(): void {
  }

  onSubmit(){

    console.log(this.user);
    this.userService.createUser(this.user).subscribe(data => {
     console.log(data);

     alert(`User has been saved successfully with these deatils
          UseriD: ${this.user.loginid}`)
    });


  }

}
