import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
      private url="http://18.118.184.243:8081"
  constructor(private http:HttpClient) { }

  credentials={
    username : '',
    password:''
  
  }

  generateToken(credentials:any){
    this.credentials=credentials;

  return this.http.post(`${this.url}/token`,credentials)
  }

 


  login(token){
    localStorage.setItem("token",token);
    localStorage.setItem("User",this.credentials.username);
    return true;
  }


  isloggedIn(){
    let Token=localStorage.getItem("token")
    if(Token==null || Token==undefined || Token==''){
      return false;
    }
    else{
      console.log(true)
      return true;
    }
  }


  logout(){

    localStorage.removeItem("token");
    return true;
  }

  getToken(){
    return localStorage.getItem('token')
  }


}
