import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from '../login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

credentials={
  username : '',
  password:''

}

  constructor(private service :LoginService, private router:Router) { }

  ngOnInit(): void {
  }


  onSubmit(){
      if((this.credentials.username!=''&& this.credentials.password!='')&&(this.credentials.username!=null&& this.credentials.password!=null)){
        this.service.generateToken(this.credentials).subscribe((data:any) =>{
console.log(data);
this.service.login(data.token)
// this.router.navigate(['/allTweets'])
window.location.href="/allTweets"


        },
        error =>{console.log(error)})
      }
      else{
      
       console.log("fields are empty!!")
      }
      console.log("Form got submitted")
  }

}
