import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Tweet } from '../tweet';
import { TweetService } from '../tweet.service';

@Component({
  selector: 'app-my-tweets',
  templateUrl: './my-tweets.component.html',
  styleUrls: ['./my-tweets.component.css']
})
export class MyTweetsComponent implements OnInit {

  tweets : Tweet[];

  constructor(private tweetService:TweetService, private router :Router) { }

  ngOnInit(): void {
    this.getTweets();
  }

  getTweets(){
   let loginid : string = localStorage.getItem('User')
    return this.tweetService.getSpecificUser(loginid).subscribe( data =>{
      console.log(localStorage.getItem('User'));
      console.log(data);
      this.tweets=data;
    })
  }

  updateTweet(tweetId : Number){
    this.router.navigate(['update-tweet',tweetId]);
  }

  deleteTweet(id :number){
    this.tweetService.deleteTweet(id).subscribe(data =>{

      console.log(data);
      this.getTweets();

    })
  }


 
}
