import { Component, OnInit } from '@angular/core';
import { LoginService } from '../login.service';

@Component({
  selector: 'app-nav-bar',
  templateUrl: './nav-bar.component.html',
  styleUrls: ['./nav-bar.component.css']
})
export class NavBarComponent implements OnInit {
 LoggedIn=false;
  constructor(private service: LoginService) { }

  ngOnInit(): void {
   this.LoggedIn= this.service.isloggedIn();
   this.loggedInUser(); 
  }

  userName ='';

  Logout(){
    this.service.logout();
   this.LoggedIn=false;
    // location.reload();
  }

    loggedInUser(){
      console.log(localStorage.getItem("User"))
     this.userName= localStorage.getItem("User");
    }

}
