import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Reply } from '../reply';
import { ReplyService } from '../reply.service';

@Component({
  selector: 'app-post-reply',
  templateUrl: './post-reply.component.html',
  styleUrls: ['./post-reply.component.css']
})
export class PostReplyComponent implements OnInit {


  reply :Reply= new Reply();
  constructor(private route: ActivatedRoute, private replyService : ReplyService,private router: Router) { }

  ngOnInit(): void {
this.reply.tweetId=this.route.snapshot.params['TweetID']
this.reply.userLoginId=localStorage.getItem("User");

  }

  onSubmit(){
    console.log(this.reply)
    this.replyService.postreply(this.reply).subscribe(data =>{
      this.router.navigate(['/allTweets']);
    },
    error=> console.log(error))


  }

}
