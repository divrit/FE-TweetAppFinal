import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Reply } from './reply';

@Injectable({
  providedIn: 'root'
})
export class ReplyService {

  constructor(private httpClient: HttpClient) { }
  private replyURL="http://18.118.184.243:8081/api/v1/reply"
  private postReply="http://18.118.184.243:8081/api/v1/reply/postReply"



  replyTweet(id :number): Observable <Reply[]>{
    return this.httpClient.get<Reply[]>(`${this.replyURL}/${id}`)
  }

postreply(reply : Reply): Observable <any>{
  console.log("I am in Service")
  console.log(`${reply.tweetId}`);
  return this.httpClient.post(`${this.postReply}/${reply.tweetId}`,reply)

}

}
