import { Reply } from './reply';

describe('Reply', () => {
  it('should create an instance', () => {
    expect(new Reply()).toBeTruthy();
  });
});
