export class Reply {


    tweetId: number;
    userLoginId : String;
    comment : String;
    repliedOn: String
    
}
