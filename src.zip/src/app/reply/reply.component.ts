import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Reply } from '../reply';
import { ReplyService } from '../reply.service';

@Component({
  selector: 'app-reply',
  templateUrl: './reply.component.html',
  styleUrls: ['./reply.component.css']
})
export class ReplyComponent implements OnInit {

  constructor( private activeroute: ActivatedRoute, private replyService : ReplyService) { }

  reply :Reply [];
  id: number;
  ngOnInit(): void {

    this.id=this.activeroute.snapshot.params['tweetID'];


    this.replyService.replyTweet(this.id).subscribe(data =>{

      this.reply=data;

    })


}

}