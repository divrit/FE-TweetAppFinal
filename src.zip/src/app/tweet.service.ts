import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders  } from '@angular/common/http'
import { Observable } from 'rxjs';
import { Tweet } from './tweet';
import { Reply } from './reply';
@Injectable({
  providedIn: 'root'
})
export class TweetService {

  private baseURL= "http://18.118.184.243:8081/api/v1/tweet/getAllTweets";
  private postURL= "http://18.118.184.243:8081/api/v1/tweet/postTweet"
  private getSpecificURL="http://18.118.184.243:8081/api/v1/tweet";
  private getTweetURL="http://18.118.184.243:8081/api/v1/tweet/getTweet"
  private updateURL="http://18.118.184.243:8081/api/v1/tweet/editTweet"
  private deleteURL= "http://18.118.184.243:8081/api/v1/tweet/deleteTweet"
  private likeURL= "http://18.118.184.243:8081/api/v1/tweet/like"


  constructor(private httpClient: HttpClient) { }

  getTweetsList(): Observable<Tweet[]>{

    return this.httpClient.get<Tweet[]>(`${this.baseURL}`);
  }

  createTweet(tweet: Tweet): Observable<Object>{

  return  this.httpClient.post(`${this.postURL}`,tweet)

  }

  getSpecificUser(id : string): Observable<Tweet[]>{

    return this.httpClient.get<Tweet[]>(`${this.getSpecificURL}/${id}`)
  }

  gettweetByID(id : number) : Observable<Tweet>{


   return  this.httpClient.get<Tweet>(`${this.getTweetURL}/${id}`);

  }

  updateTweet(id : number, tweet: Tweet): Observable<Object>{
   
    return this.httpClient.put(`${this.updateURL}/${id}`, tweet,{ responseType: 'text' });
  }


  deleteTweet(id : number): Observable<Object>{


    return this.httpClient.delete(`${this.deleteURL}/${id}`,{ responseType: 'text' });



  }

  likeTweet(id : number): Observable<any>{
    return this.httpClient.put(`${this.likeURL}/${id}`,{ responseType: 'text' });
  }


 

}
