export class Tweet {


   tweetId: number;
   userLoginId : String;
   message : String;
    postedOn : String;
   likes : number;
}
