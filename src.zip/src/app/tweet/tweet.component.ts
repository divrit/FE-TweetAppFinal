import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Reply } from '../reply';
import { ReplyService } from '../reply.service';
import { Tweet } from '../tweet';
import { TweetService } from '../tweet.service';

@Component({
  selector: 'app-tweet',
  templateUrl: './tweet.component.html',
  styleUrls: ['./tweet.component.css']
})
export class TweetComponent implements OnInit {

  tweets: Tweet[];
  replies: Reply[];

  constructor(private tweetService : TweetService, private router: Router, private replyService :ReplyService) {
   }

  ngOnInit(): void {
    this.getTweets();
 
  }

  viewReply(id: number) {

    this.router.navigate(['app-reply',id]);
   
  }

    private getTweets(){
        this.tweetService.getTweetsList().subscribe(data => {
          this.tweets= data;  
        });
      }


      likeTweet(id : number){
        this.tweetService.likeTweet(id).subscribe(data =>{
          this.getTweets();
        })
      


      }


      replyTweet(id:number){
        console.log("Inside reply ")
     
          this.router.navigate(['app-post-reply',id])
    

      }

  }


