import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { error } from 'selenium-webdriver';
import { Tweet } from '../tweet';
import { TweetService } from '../tweet.service';

@Component({
  selector: 'app-update-tweet',
  templateUrl: './update-tweet.component.html',
  styleUrls: ['./update-tweet.component.css']
})
export class UpdateTweetComponent implements OnInit {

  tweet :Tweet = new Tweet();
  id: number;
 
  constructor(private tweetService:TweetService, private activeroute: ActivatedRoute, private route :Router) { }

  ngOnInit(): void {

    this.id=this.activeroute.snapshot.params['tweetID']
    this.tweetService.gettweetByID(this.id).subscribe(data =>{
this.tweet=data;


    })

  }

  onSubmit(){
    this.tweetService.updateTweet(this.id, this.tweet).subscribe(data => {
        this.goToTweets();
       
    },
    error => console.log(error)
    )

  }

  goToTweets(){
  this.route.navigate(['my-tweets']);
  }
}
