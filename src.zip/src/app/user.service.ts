import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { User } from './user';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  private BaseURL="http://18.118.184.243:8081/api/v1/user/register";

  constructor(private httpClien: HttpClient) { }

  createUser(user :User):Observable<Object>{
    console.log(user)

   return  this.httpClien.post(`${this.BaseURL}`,user, {responseType: 'text'});
  }
}
