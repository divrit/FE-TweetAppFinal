export class User {
    firstname : string;
    lastname : string;  
    email : string;
    loginid : string;
    password : string;
    contact : number;
}
